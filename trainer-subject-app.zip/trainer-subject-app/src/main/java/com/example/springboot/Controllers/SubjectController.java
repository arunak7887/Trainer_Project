package com.example.springboot.Controllers;

import com.example.springboot.model.Subject;
import com.example.springboot.Repositories.SubjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/subject")
@CrossOrigin
public class SubjectController {

    @Autowired
    private SubjectRepository subjectRepo;

    @PostMapping
    public Subject addSubject(@RequestBody Subject subject) {
        return subjectRepo.save(subject);
    }

    @GetMapping
    public List<Subject> getAllSubjects() {
        return subjectRepo.findAll();
    }

    @GetMapping("/{id}")
    public Subject getSubjectWithTrainers(@PathVariable Long id) {
        return subjectRepo.findById(id).orElse(null);
    }
}
