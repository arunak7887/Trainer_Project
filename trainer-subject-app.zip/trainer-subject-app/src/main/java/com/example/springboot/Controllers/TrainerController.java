package com.example.springboot.Controllers;

import com.example.springboot.Repositories.TrainerRepository;
import com.example.springboot.model.Trainer;
import com.example.springboot.Repositories.SubjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/trainer")
@CrossOrigin
public class TrainerController {

    @Autowired
    private TrainerRepository trainerRepo;

    @PostMapping
    public Trainer addTrainer(@RequestBody Trainer trainer) {
        return trainerRepo.save(trainer);
    }

    @GetMapping
    public List<Trainer> getAll() {
        return trainerRepo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Trainer> getById(@PathVariable Long id) {
        return trainerRepo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping
    public void deleteTrainer(@RequestParam Long id) {
        trainerRepo.deleteById(id);
    }

    @GetMapping("/{subject}/topic")
    public List<Trainer> getBySubject(@PathVariable String subject) {
        return trainerRepo.findBySubjects_Name(subject);
    }
}
