function addTrainer() {
    const name = document.getElementById('trainerName').value;
    const empId = document.getElementById('empId').value;

    fetch('/trainer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, empId })
    })
    .then(res => res.json())
    .then(() => alert('Trainer added!'));
}

function addSubject() {
    const name = document.getElementById('subjectName').value;

    fetch('/subject', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name })
    })
    .then(res => res.json())
    .then(() => alert('Subject added!'));
}

function getTrainers() {
    fetch('/trainer')
        .then(res => res.json())
        .then(data => {
            const list = document.getElementById('trainerList');
            list.innerHTML = '';
            data.forEach(t => {
                const li = document.createElement('li');
                li.textContent = `${t.name} (${t.empId})`;
                list.appendChild(li);
            });
        });
}

function getSubjects() {
    fetch('/subject')
        .then(res => res.json())
        .then(data => {
            const list = document.getElementById('subjectList');
            list.innerHTML = '';
            data.forEach(s => {
                const li = document.createElement('li');
                li.textContent = `${s.name}`;
                list.appendChild(li);
            });
        });
}

function getTrainersBySubject() {
    const subject = document.getElementById('findSubject').value;
    fetch(`/trainer/${subject}/topic`)
        .then(res => res.json())
        .then(data => {
            const list = document.getElementById('subjectTrainerList');
            list.innerHTML = '';
            data.forEach(t => {
                const li = document.createElement('li');
                li.textContent = `${t.name} (${t.empId})`;
                list.appendChild(li);
            });
        });
}
